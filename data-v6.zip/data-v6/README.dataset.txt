# potathon > 2024-08-17 6:46pm
https://universe.roboflow.com/danel-adendorff/potathon

Provided by a Roboflow user
License: CC BY 4.0

